#include <iostream>

// CSC 134
// M1T1
// Hunterm

using namespace std;

int main()
{
    cout << "Hello from CSC-134!" << endl;
    cout << "Quack" << endl;
    return 0;
}
